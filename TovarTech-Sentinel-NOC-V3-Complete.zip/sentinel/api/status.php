<?php
header('Content-Type: application/json');
header('Cache-Control: no-store');
require __DIR__ . '/db.php';
$pdo=db();
$config=json_decode(file_get_contents(dirname(__DIR__).'/config/endpoints.json'),true) ?: [];
$out=[];$online=0;$offline=0;$responses=[];
foreach($config as $ep){
 $st=$pdo->prepare("SELECT * FROM checks WHERE endpoint_name=? ORDER BY id DESC LIMIT 1");$st->execute([$ep['name']]);$last=$st->fetch(PDO::FETCH_ASSOC);
 $hs=$pdo->prepare("SELECT status FROM checks WHERE endpoint_name=? ORDER BY id DESC LIMIT 24");$hs->execute([$ep['name']]);$hist=array_reverse(array_map(fn($r)=>$r['status']==='ONLINE'?1:0,$hs->fetchAll(PDO::FETCH_ASSOC)));
 if($last){if($last['status']==='ONLINE'){$online++;if($last['response_ms']!==null)$responses[]=(int)$last['response_ms'];}else{$offline++;}}
 $out[]=[
  'name'=>$ep['name'],'url'=>$ep['url'],'status'=>$last['status']??'UNKNOWN',
  'http_code'=>$last['http_code']??null,'response_ms'=>$last['response_ms']??null,
  'dns_ok'=>isset($last['dns_ok'])?(bool)$last['dns_ok']:false,'ssl_days'=>$last['ssl_days']??null,
  'port_ok'=>isset($last['port_ok'])?(bool)$last['port_ok']:false,'checked_at'=>$last['checked_at']??null,'history'=>$hist
 ];
}
$events=$pdo->query("SELECT event_type,message,created_at FROM events ORDER BY id DESC LIMIT 40")->fetchAll(PDO::FETCH_ASSOC);
echo json_encode(['summary'=>['online'=>$online,'offline'=>$offline,'avg_response_ms'=>count($responses)?round(array_sum($responses)/count($responses)):null],'endpoints'=>$out,'events'=>$events]);
?>