<?php
header('Cache-Control: no-store,no-cache,must-revalidate,max-age=0');
$mode=$_GET['mode']??'ping';
if($mode==='ping'){header('Content-Type:text/plain');echo 'pong';exit;}
if($mode==='download'){
 $mb=max(1,min((int)($_GET['mb']??4),16));$bytes=$mb*1024*1024;
 header('Content-Type:application/octet-stream');header('Content-Length:'.$bytes);
 $chunk=str_repeat('SENTINEL-',8192);$chunk=substr($chunk,0,65536);$sent=0;
 while($sent<$bytes){$n=min(65536,$bytes-$sent);echo substr($chunk,0,$n);$sent+=$n;if(function_exists('ob_flush'))@ob_flush();flush();}exit;
}
if($mode==='upload' && $_SERVER['REQUEST_METHOD']==='POST'){
 $in=fopen('php://input','rb');$received=0;while(!feof($in)){$d=fread($in,1048576);$received+=strlen($d);}fclose($in);
 header('Content-Type:application/json');echo json_encode(['ok'=>true,'receivedBytes'=>$received]);exit;
}
http_response_code(400);echo 'bad request';
?>