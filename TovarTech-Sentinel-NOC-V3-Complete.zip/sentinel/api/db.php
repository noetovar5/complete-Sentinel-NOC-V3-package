<?php
function db(): PDO {
    $path = dirname(__DIR__) . '/data/sentinel.db';
    $pdo = new PDO('sqlite:' . $path);
    $pdo->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
    $pdo->exec("PRAGMA journal_mode=WAL;");
    $pdo->exec("CREATE TABLE IF NOT EXISTS checks (
      id INTEGER PRIMARY KEY AUTOINCREMENT,
      endpoint_name TEXT NOT NULL,url TEXT NOT NULL,status TEXT NOT NULL,
      http_code INTEGER,response_ms INTEGER,dns_ok INTEGER,ssl_days INTEGER,
      port_ok INTEGER,checked_at TEXT NOT NULL
    )");
    $pdo->exec("CREATE TABLE IF NOT EXISTS events (
      id INTEGER PRIMARY KEY AUTOINCREMENT,
      endpoint_name TEXT,event_type TEXT,message TEXT,created_at TEXT NOT NULL
    )");
    return $pdo;
}
?>