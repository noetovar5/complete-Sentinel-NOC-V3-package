<?php
require dirname(__DIR__).'/api/db.php';
$pdo=db();
echo "Sentinel database initialized successfully.\n";
?>