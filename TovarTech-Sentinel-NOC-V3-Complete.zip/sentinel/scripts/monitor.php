<?php
require dirname(__DIR__).'/api/db.php';
$pdo=db();
$config=json_decode(file_get_contents(dirname(__DIR__).'/config/endpoints.json'),true) ?: [];
function sslDays($host,$port=443){
 $ctx=stream_context_create(['ssl'=>['capture_peer_cert'=>true,'verify_peer'=>false,'verify_peer_name'=>false]]);
 $c=@stream_socket_client("ssl://$host:$port",$errno,$errstr,4,STREAM_CLIENT_CONNECT,$ctx);
 if(!$c)return null;$p=stream_context_get_params($c);if(empty($p['options']['ssl']['peer_certificate']))return null;
 $info=openssl_x509_parse($p['options']['ssl']['peer_certificate']);return isset($info['validTo_time_t'])?(int)floor(($info['validTo_time_t']-time())/86400):null;
}
foreach($config as $ep){
 $url=$ep['url'];$u=parse_url($url);$host=$u['host']??'';$port=(int)($ep['port']??(($u['scheme']??'https')==='https'?443:80));
 $dnsOk=$host && gethostbyname($host)!==$host;
 $portOk=false;$sock=@fsockopen($host,$port,$errno,$errstr,4);if($sock){$portOk=true;fclose($sock);}
 $start=microtime(true);$ch=curl_init($url);curl_setopt_array($ch,[CURLOPT_RETURNTRANSFER=>true,CURLOPT_FOLLOWLOCATION=>true,CURLOPT_TIMEOUT=>10,CURLOPT_CONNECTTIMEOUT=>5,CURLOPT_USERAGENT=>'TovarTech-Sentinel/3.0',CURLOPT_SSL_VERIFYPEER=>true]);
 $body=curl_exec($ch);$http=curl_getinfo($ch,CURLINFO_HTTP_CODE);$curlErr=curl_errno($ch);curl_close($ch);$ms=(int)round((microtime(true)-$start)*1000);
 $expected=$ep['expected_text']??'';$contentOk=$expected==='' || ($body!==false && stripos($body,$expected)!==false);
 $online=(!$curlErr && $http>=200 && $http<400 && $contentOk && $portOk);
 $status=$online?'ONLINE':'OFFLINE';$ssl=(($u['scheme']??'')==='https')?sslDays($host,$port):null;
 $prev=$pdo->prepare("SELECT status FROM checks WHERE endpoint_name=? ORDER BY id DESC LIMIT 1");$prev->execute([$ep['name']]);$old=$prev->fetchColumn();
 $ins=$pdo->prepare("INSERT INTO checks(endpoint_name,url,status,http_code,response_ms,dns_ok,ssl_days,port_ok,checked_at) VALUES(?,?,?,?,?,?,?,?,datetime('now','localtime'))");
 $ins->execute([$ep['name'],$url,$status,$http?:null,$ms,$dnsOk?1:0,$ssl,$portOk?1:0]);
 if($old!==false && $old!==$status){
  $type=$status==='ONLINE'?'RECOVERY':'INCIDENT';$msg=$ep['name'].' changed from '.$old.' to '.$status.' (HTTP '.($http?:'N/A').')';
  $ev=$pdo->prepare("INSERT INTO events(endpoint_name,event_type,message,created_at) VALUES(?,?,?,datetime('now','localtime'))");$ev->execute([$ep['name'],$type,$msg]);
 }
 echo date('Y-m-d H:i:s')." {$ep['name']} => $status HTTP=$http {$ms}ms DNS=".($dnsOk?'OK':'FAIL')." PORT=".($portOk?'OPEN':'CLOSED')." SSL=".($ssl??'NA')."\n";
}
?>