#!/usr/bin/env bash
set -e
echo "=== Tovar Tech Sentinel NOC V3 installer ==="
if [ "$EUID" -ne 0 ]; then echo "Run with sudo."; exit 1; fi
apt update
apt install -y apache2 php libapache2-mod-php php-curl php-sqlite3 sqlite3 openssl ca-certificates ufw
systemctl enable --now apache2
mkdir -p /var/www/html/sentinel/data
chown -R www-data:www-data /var/www/html/sentinel
chmod 755 /var/www/html/sentinel
chmod 775 /var/www/html/sentinel/data
php /var/www/html/sentinel/scripts/init_db.php
cp /var/www/html/sentinel/scripts/sentinel-monitor.service /etc/systemd/system/
cp /var/www/html/sentinel/scripts/sentinel-monitor.timer /etc/systemd/system/
systemctl daemon-reload
systemctl enable --now sentinel-monitor.timer
ufw allow OpenSSH || true
ufw allow 'Apache Full' || true
echo
echo "Installation complete."
echo "Open: http://SERVER-IP/sentinel/"
echo "Check timer: systemctl status sentinel-monitor.timer"
echo "Run immediate scan: sudo -u www-data php /var/www/html/sentinel/scripts/monitor.php"
