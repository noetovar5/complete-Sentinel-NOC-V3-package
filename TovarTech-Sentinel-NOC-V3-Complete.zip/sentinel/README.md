# Tovar Tech Sentinel NOC V3

A lightweight Linux-hosted infrastructure monitoring dashboard for website/application health.

## Included
- Futuristic HTML dashboard
- PHP status API
- SQLite telemetry database
- 60-second Linux systemd monitoring timer
- HTTP/HTTPS health
- HTTP response code
- response time
- DNS resolution
- TCP port reachability
- SSL certificate expiration days
- incident/recovery events
- 24-check visual history
- browser-to-server download/upload/latency/jitter test

## Configure endpoints
Edit:
config/endpoints.json

Maximum is not hard-coded. You may add more endpoints, though the UI is designed around a small NOC.

Example:
{
  "name": "My Site",
  "url": "https://example.com",
  "port": 443,
  "expected_text": "Example"
}

`expected_text` may be blank. If populated, the monitor verifies that text is present in the returned page.

## Main install
Place the extracted folder at:
/var/www/html/sentinel

Then:
cd /var/www/html/sentinel
sudo ./install.sh
