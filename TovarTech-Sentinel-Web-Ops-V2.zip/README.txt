TOVAR TECH SENTINEL WEB OPS - V2 INSTALLATION

FILES
1. tovartech-sentinel-web-monitor-v2.html
2. speedtest.php

INSTALLATION
Upload both files into the SAME directory on your Apache/PHP server.

Example:
/var/www/html/monitor/index.html
/var/www/html/monitor/speedtest.php

You may rename:
tovartech-sentinel-web-monitor-v2.html -> index.html

Then open:
https://yourdomain.com/monitor/

REQUIREMENTS
- Apache or NGINX
- PHP enabled
- HTTPS recommended

The website endpoint monitor remains browser-side.
The bandwidth module uses speedtest.php to:
- Measure latency
- Estimate jitter
- Transfer download test packets
- Receive upload test packets

IMPORTANT
This measures the bandwidth between the browser/device and the server hosting Sentinel.
It is not an ICMP test and it is not a direct router/ISP modem speed test.

Security:
speedtest.php does not save uploaded data to disk.
It discards test payloads immediately after counting the received bytes.
