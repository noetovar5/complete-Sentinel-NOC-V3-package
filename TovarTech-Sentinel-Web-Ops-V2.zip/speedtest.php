<?php
// Tovar Tech Sentinel Web Ops - bandwidth helper
// Place this file in the same web directory as the HTML dashboard.

header('Cache-Control: no-store, no-cache, must-revalidate, max-age=0');
header('Pragma: no-cache');
header('Access-Control-Allow-Origin: *');
header('Access-Control-Allow-Methods: GET, POST, OPTIONS');
header('Access-Control-Allow-Headers: Content-Type');

if ($_SERVER['REQUEST_METHOD'] === 'OPTIONS') {
    http_response_code(204);
    exit;
}

$mode = isset($_GET['mode']) ? $_GET['mode'] : 'ping';

if ($mode === 'ping') {
    header('Content-Type: text/plain');
    echo "pong";
    exit;
}

if ($mode === 'download') {
    $mb = isset($_GET['mb']) ? intval($_GET['mb']) : 4;
    $mb = max(1, min($mb, 16)); // safety limit: 1-16 MB per request
    $bytes = $mb * 1024 * 1024;

    header('Content-Type: application/octet-stream');
    header('Content-Length: ' . $bytes);

    // Send repeated 64 KB blocks to avoid allocating the entire file in RAM.
    $chunk = str_repeat("SENTINEL-BANDWIDTH-PACKET-", 2731);
    $chunk = substr($chunk, 0, 65536);
    $sent = 0;

    while ($sent < $bytes) {
        $remaining = $bytes - $sent;
        $out = ($remaining >= 65536) ? $chunk : substr($chunk, 0, $remaining);
        echo $out;
        $sent += strlen($out);
        if (function_exists('ob_flush')) @ob_flush();
        flush();
    }
    exit;
}

if ($mode === 'upload' && $_SERVER['REQUEST_METHOD'] === 'POST') {
    $input = fopen('php://input', 'rb');
    $received = 0;
    while (!feof($input)) {
        $data = fread($input, 1024 * 1024);
        $received += strlen($data);
    }
    fclose($input);

    header('Content-Type: application/json');
    echo json_encode([
        'ok' => true,
        'receivedBytes' => $received,
        'serverTime' => gmdate('c')
    ]);
    exit;
}

http_response_code(400);
header('Content-Type: application/json');
echo json_encode(['ok' => false, 'error' => 'Invalid mode']);
?>